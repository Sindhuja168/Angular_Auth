import { Component } from '@angular/core';

@Component({
  selector: 'app-main1',
  standalone: true,
  imports: [],
  templateUrl: './main1.component.html',
  styleUrl: './main1.component.css'
})
export class Main1Component {

}
