import { Component } from '@angular/core';

@Component({
  selector: 'app-main2',
  standalone: true,
  imports: [],
  templateUrl: './main2.component.html',
  styleUrl: './main2.component.css'
})
export class Main2Component {

}
